//
//  HistoryDetailVC.swift
//  YogiYoCloneIOS
//
//  Created by 김믿음 on 2020/09/29.
//  Copyright © 2020 김동현. All rights reserved.
//

import UIKit

class HistoryDetailVC: UIViewController {

    // leading, trailing padding
    private let padding = 20
    
    // 최상위 wrap View
    private let wrapView: UIView = {
        let wrapView = UIView()
        return wrapView
    }()
    
    // 닫기 버튼
    private let closeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(systemName: "xmark"), for: .normal)
        button.imageView?.tintColor = .black
        button.contentVerticalAlignment = .fill
        button.contentHorizontalAlignment = .fill
        button.backgroundColor = .white
        
//         button.addTarget(self, action: #selector(filtercloseButton), for: .touchUpInside)
        return button
    }()
    
    // 컨텐츠 스크롤뷰
    private let scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.contentSize = CGSize(width: 1200, height: Int(scrollView.frame.size.height))
        scrollView.alwaysBounceHorizontal = false
        scrollView.alwaysBounceVertical = true
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()
    
    // 상점이름 및 링크
    private let storeView: UIButton = {
        let button = UIButton()
        button.setTitle("바비박스 (POS MENU FINAL)", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        button.imageView?.tintColor = .gray
        button.contentVerticalAlignment = .fill
        button.contentHorizontalAlignment = .fill
        return button
    }()
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        configureView()
    }
    
    // MARK: layout view 만들기
    func configureView() {
        drawWrap(parentView: view)
        drawCloseButton(parentView: wrapView)
        drawScroll(parentView: wrapView)
        drawStore(parentView: scrollView)
        
    }
    
    // section
    func drawSection() {
        
    }
    
    // stack 한줄 한줄 보여주는 부분
    func drawStackLine() {
        
    }
    
    // wrapView 그리기
    func drawWrap(parentView: UIView) {
        parentView.addSubview(wrapView)
        wrapView.snp.makeConstraints { (make) in
            make.top.equalTo(parentView).offset(90)
            make.bottom.equalTo(parentView)
        }
        fillLayoutConstraints(target: wrapView, to: view)
        
        
    }
    
    // 닫기 버튼
    func drawCloseButton(parentView: UIView) {
        parentView.addSubview(closeButton)
        closeButton.snp.makeConstraints { (make) in
            make.width.height.equalTo(30)
            make.leading.equalTo(parentView).offset(padding)
            make.top.equalTo(parentView).offset(20)
        }
    }
    
    // 상세내용 스크롤뷰
    func drawScroll(parentView: UIView) {
        parentView.addSubview(scrollView)
        scrollView.snp.makeConstraints { (make) in
            make.top.equalTo(closeButton.snp.bottom)
            make.bottom.equalTo(parentView)
            make.leading.equalTo(parentView).inset(50)
            make.trailing.equalTo(parentView).inset(50)
        }
        commonConstraints(target: scrollView, to: parentView, prev: closeButton, offset: 0)
    }
    
    // 상점이름 및 링크
    func drawStore(parentView: UIView) {
        parentView.addSubview(storeView)
        commonConstraints(target: storeView, to: parentView, prev: closeButton)
    }
    
    // 재주문 버튼
    func drawReOrderButton() {
        
    }
    
    // 일반적 section 공통 제약 조건
    func commonConstraints(target: UIView, to: UIView, prev: UIView, offset: Int = 20) {
        loactedTopContsraints(target: target, to: prev, offset: offset)
        fillLayoutConstraints(target: target, to: to)
    }
    
    // top margin 공통 autolayout 제약
    func loactedTopContsraints(target: UIView, to: UIView, offset: Int = 20) {
        target.snp.makeConstraints { (make) in
            make.top.equalTo(to.snp.bottom).offset(offset)
        }
    }
    
    // 가득채우는 width 공통 제약 조건
    func fillLayoutConstraints(target: UIView, to: UIView) {
        target.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(to)
        }
    }
    
}
